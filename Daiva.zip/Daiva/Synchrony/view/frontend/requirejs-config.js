var config = {
    map: {
        '*': {
            'Magento_Checkout/js/action/place-order':'Daiva_Synchrony/js/action/place-order'
        }
    }
};
