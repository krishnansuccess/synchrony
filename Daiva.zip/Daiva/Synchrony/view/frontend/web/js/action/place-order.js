/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * @api
 */
define(['jquery',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/url-builder',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/model/place-order',
    'Daiva_Synchrony/js/model/merchant',
    'mage/url'
], function ($,quote, urlBuilder, customer, placeOrderService, merchant, url) {
    'use strict';
    
    return function (paymentData, messageContainer) {
        var serviceUrl, payload;

        payload = {
            cartId: quote.getQuoteId(),
            billingAddress: quote.billingAddress(),
            paymentMethod: paymentData
        };
        var JSONObject = {};

        JSONObject.processInd = 1;

        JSONObject.tokenId = 53481203403020901551204899773;

        JSONObject.merchantID = 5348120340302090;

        JSONObject.clientTransId = 'clienttransactiontest1234';

        JSONObject.cardNumber = 5046620191801729;

        $.ajax({
            url: url.build('synchrony/payment/authentication'),
            type: 'GET',
            contentType: 'application/json',
            success:function(res){
                calldBuyProcess1(null,JSONObject, redirectToNextPage());
            }
        });
        return false;
        if (customer.isLoggedIn()) {
            serviceUrl = urlBuilder.createUrl('/carts/mine/payment-information', {});
        } else {
            serviceUrl = urlBuilder.createUrl('/guest-carts/:quoteId/payment-information', {
                quoteId: quote.getQuoteId()
            });
            payload.email = quote.guestEmail;
        }

        return placeOrderService(serviceUrl, payload, messageContainer);
    };
});
