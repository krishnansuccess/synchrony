<?php


namespace Daiva\Synchrony\Model\Payment;

class Synchrony extends \Magento\Payment\Model\Method\AbstractMethod
{

    protected $_code = "synchrony";
    protected $_isOffline = true;

    public function isAvailable(
        \Magento\Quote\Api\Data\CartInterface $quote = null
    ) {
        return parent::isAvailable($quote);
    }
}
