<?php


namespace Daiva\Synchrony\Controller\Payment;

class Authentication extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;
    protected $jsonHelper;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Json\Helper\Data $jsonHelper
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->jsonHelper = $jsonHelper;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        try {
            $result=[];
            $ch = curl_init();
            $config_method = 'POST';
            // Replace MXXX with MID
            // Replace PXXX with password
            $fields = array("merchantId" => "5348120340302090", "password" => "ydx+c1EFsCSUaJ7nd5f62g=="); 
            $config_headers[] = 'Accept: application/xml'; 
            // The URL below is to target the test region 
            $config_address = "https://ubuy.syf.com/DigitalBuy/authentication.do"; 
            // The URL below is to target the production region (currently commented out) //$config_address = ' https://buy.syf.com/DigitalBuy/authentication.do'; 
            $chandle = curl_init();

            curl_setopt($chandle, CURLOPT_RETURNTRANSFER, true); 
            curl_setopt($chandle, CURLOPT_URL, $config_address); 
            curl_setopt($chandle, CURLOPT_HTTPHEADER, $config_headers); 
            curl_setopt($chandle, CURLOPT_POSTFIELDS, http_build_query($fields)); 
            curl_setopt($chandle, CURLOPT_SSL_VERIFYPEER, false); 
            $response = curl_exec($chandle); 
            $errmsg = curl_error($chandle); 
            $cInfo = curl_getinfo($chandle); 
            curl_close($chandle); 
            if ($errmsg =="")
            {
                $responseobj=json_decode($response); 
                if($responseobj != null)
                {
                    $result['postbackid'] = $responseobj->postbackid;
                    $result['clientToken'] = $responseobj->clientToken;
                    $result['message'] ='';
                }
                else {
                    $result['clientToken'] =null;
                    $result['message'] ='Tokens Not Generated Successfully';
                } 
            } 
            else { 
                $result['clientToken'] =null;
                $result['message'] ="There is a Problem, ". $errmsg ;
            } 
            return $this->jsonResponse($result);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            return $this->jsonResponse($e->getMessage());
        } catch (\Exception $e) {
            $this->logger->critical($e);
            return $this->jsonResponse($e->getMessage());
        }
    }

    /**
     * Create json response
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function jsonResponse($response = '')
    {
        return $this->getResponse()->representJson(
            $this->jsonHelper->jsonEncode($response)
        );
    }
}