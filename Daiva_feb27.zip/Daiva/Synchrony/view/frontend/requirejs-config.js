var config = {
    map: {
        '*': {
            'Magento_Checkout/js/action/place-order':'Daiva_Synchrony/js/action/place-order'
        }
    },
    paths: {
        "bootstrap.min": "Daiva_Synchrony/js/bootstrap.min"
    },
    shim: {
        'bootstrap.min': {
            'deps': ['jquery']
        }
    }
};
