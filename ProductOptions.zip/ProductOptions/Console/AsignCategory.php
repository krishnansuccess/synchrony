<?php

namespace Wilsonart\ProductOptions\Console;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Framework\App\State as AppState;
class AsignCategory extends Command {
 protected $appState;
 protected $productFactory;
    protected $resource;
    public function __construct(AppState $appState, \Magento\Framework\App\ResourceConnection $resource, \Magento\Catalog\Model\ProductFactory $productFactory) {
        parent::__construct();
        $this->appState = $appState;
        $this->productFactory = $productFactory;
        $this->resource = $resource;
    }

    protected function configure() {
        $this->setName('wilosonart:assigcategory');
        $this->setDescription('Assign category to the Laminart Products');
    }

    protected function execute(InputInterface $input, OutputInterface $output) {
        $this->appState->setAreaCode('catalog');
          
             $datas=$this->getFilters();
        $product=$this->productFactory->create();
        foreach($datas as $pid => $categories){
            try {
        $product->load($pid);
        //$product->setStoreId($categories);
        $product->setCategoryIds($categories);
        $product->save();
        $product->unsetData(); 
        } catch (\Exception $e) {
             
                 try {
            $product->load($pid);
        //$product->setStoreId($categories);
        $product->setCategoryIds($categories);
        $product->setUrlKey(str_replace(" ","",strtolower($product->getName())));
        $product->save();
        $product->unsetData(); 
         } catch (\Exception $e) {
             $output->writeln($product->getName()."--Exception".$e->getMessage());
         }
           
        }
        }
        
        
        
        $output->writeln("Category assigned successfully");
    }
     protected function getFilters() {
        $connection = $this->getConnection();
        $sql = "select product_id,category_id from laminart_product_description";
        $data= $connection->fetchAll($sql);
        $products=[];
        foreach($data as $d){
            if(isset($products[$d['product_id']]) && in_array($d['category_id'], $products[$d['product_id']]))
                    continue;
         $products[$d['product_id']][]= $d['category_id'];  
        }
        return $products;
    }
     protected function getConnection() {
        $connection = $this->resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        return $connection;
    }

}
