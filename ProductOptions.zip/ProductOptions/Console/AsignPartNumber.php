<?php

namespace Wilsonart\ProductOptions\Console;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Framework\App\State as AppState;

class AsignPartNumber extends Command {

    protected $appState;
    protected $productFactory;
    protected $productRepository;
    protected $resource;
    protected $statusUpdater;

    public function __construct(AppState $appState, \Magento\Catalog\Model\Product\Action $statusUpdater, \Magento\Catalog\Api\ProductRepositoryInterface $productRepository, \Magento\Framework\App\ResourceConnection $resource, \Magento\Catalog\Model\ProductFactory $productFactory) {
        parent::__construct();
        $this->appState = $appState;
        $this->productRepository = $productRepository;
        $this->productFactory = $productFactory;
        $this->statusUpdater = $statusUpdater;
        $this->resource = $resource;
    }

    protected function configure() {
        $this->setName('laminart:syncpartnumber');
        $this->setDescription('Asign PartNumber to Laminart products');
    }

    protected function execute(InputInterface $input, OutputInterface $output) {
        $this->appState->setAreaCode('crontab');
        try {
            $datas = $this->getFilters();
            foreach ($datas as $pid => $partnumber) {
                echo $partnumber[0]."\n";
                $this->statusUpdater->updateAttributes([$pid], ['part_number' => $partnumber[0]], 3);
            }
        } catch (\Exception $e) {
            $output->writeln("Exception" . $e->getMessage());
        }
        $output->writeln("Assigned Successfully");
    }

    protected function getFilters() {
        $connection = $this->getConnection();
        $sql = "select product_id,GROUP_CONCAT(partnumber SEPARATOR ',') as partnumber from laminart_product_description GROUP BY product_id";
        $data = $connection->fetchAll($sql);
        $products = [];
        foreach ($data as $d) {
            $products[$d['product_id']][] = $d['partnumber'];
        }
        return $products;
    }

    protected function getConnection() {
        $connection = $this->resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        return $connection;
    }

    public function logCreate($fileName, $data) {
        $writer = new \Zend\Log\Writer\Stream(BP . "$fileName");
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($data);
    }

}
