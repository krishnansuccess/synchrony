<?php

/**
 *
 * Copyright © 2015 Wilsonartcommerce. All rights reserved.
 */

namespace Wilsonart\ProductOptions\Controller\Filters;

class Index extends \Magento\Framework\App\Action\Action {

    protected $resource;
    protected $resultPageFactory;
    protected $optionValueCollectionFactory;
    protected $productOptions;
    protected $laminartFilters;
    protected $priceHelper;

    public function __construct(\Magento\Framework\Pricing\Helper\Data $priceHelper, \Magento\Framework\App\Action\Context $context, \Magento\Framework\App\ResourceConnection $resource, \Magento\Catalog\Model\ResourceModel\Product\Option\Value\CollectionFactory $optionValueCollectionFactory
    ) {
        parent::__construct($context);

        $this->resource = $resource;
        $this->priceHelper = $priceHelper;
        $this->optionValueCollectionFactory = $optionValueCollectionFactory;
    }

    protected function getConnection() {
        $connection = $this->resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        return $connection;
    }

    public function execute() {
   
        $result = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_JSON);

        $productIds = $this->getRequest()->getParam('pids',[]);
        if( count($productIds)<=0){
            $result->setData([]);
            return $result;
        }
         $searchQuery = $this->getRequest()->getParam('searchkeyword');
         $is_stocked=$this->getRequest()->getParam('is_stocked');

        $pids = [];
        foreach ($productIds as $pro) {
            $pids[] = $pro['pid'];
        }

        $this->productOptions = $this->getOptions($pids);
        $this->laminartFilters = $this->getFilters($pids,$searchQuery,$is_stocked);
        
        $resultData = [];
        foreach ($productIds as $pro) {
               $resultData[] = ['product_id' => $pro['pid'], 'cat_id' => $pro['cat_id'], 'product_type' => $this->getProductType($pro['pid'], $pro['cat_id'])];

        }

        $result->setData($resultData);
        return $result;
    }

    protected function getProductType($pid, $catId) {
        $pro_types = [];
        $keys = [];
        
        foreach ($this->laminartFilters as $filter) {
            if ($pid == $filter['product_id'] && $catId == $filter['category_id']) {

                foreach ($this->productOptions as $option) {
                    if (!in_array(trim($filter['attribute_4']), $keys) && $pid == $option['product_id'] && trim($option['title']) == trim($filter['attribute_4'])) {
                        $keys[] = trim($filter['attribute_4']);
                        $pro_types[] = ["cat_id" => $filter['category_id'], "pid" => $option['product_id'], "id" => $option['option_type_id'], "title" => $option['title'], "finish" => $this->getFinish($pid, $catId, $filter['attribute_4'])];
                    }
                }
            }
        }

        return $pro_types;
    }

    protected function getFinish($pid, $catId,$product_type) {
        $finishes = [];
        $keys = [];
        foreach ($this->laminartFilters as $filter) {
            if ($pid == $filter['product_id'] && $catId == $filter['category_id'] && $product_type == $filter['attribute_4']) {

                foreach ($this->productOptions as $option) {
                    if (!in_array(trim($filter['attribute_5']), $keys) && $pid == $option['product_id'] && trim($option['title']) == trim($filter['attribute_5'])) {
                        $keys[] = trim($filter['attribute_5']);
                        $finishes[] = ["cat_id" => $filter['category_id'], "pid" => $option['product_id'], "id" => $option['option_type_id'], "title" => $option['title'], "sizes" => $this->getSize($pid, $catId, $product_type,$filter['attribute_5'])];
                    }
                }
            }
        }

        return $finishes;
    }

    protected function getSize($pid, $catId, $product_type,$finish) {
        $sizes = [];
        $keys = [];

        foreach ($this->laminartFilters as $filter) {

            if ($pid == $filter['product_id'] && $catId == $filter['category_id'] && $product_type == $filter['attribute_4'] && $finish == $filter['attribute_5']) {
                $size = $filter['attribute_2'] . "X" . $filter['attribute_3'];
               
                $size = str_replace(' ', '', $size);
                foreach ($this->productOptions as $option) {

                    if (!in_array($size, $keys) && $pid == $option['product_id'] && str_replace(' ', '', $option['title']) == $size) {
                        $keys[] = $size;

                        $sizes[] = ["cat_id" => $filter['category_id'], "pid" => $option['product_id'], "id" => $option['option_type_id'], "title" => $option['title'], "part_no" => $this->getPartNo($pid, $catId,$product_type, $filter['attribute_5'], $size)];
                    }
                }
            }
        }
        return $sizes;
    }

    protected function getPartNo($pid, $catId, $product_type,$finish, $size) {
        $parts = [];
        $keys = [];
        $types=['default'=>'','FR'=>'Fire Rated','OS'=>'Oyster Shield','P'=>'Peel Coating'];
        foreach ($this->laminartFilters as $filter) {
            $tempSize = $filter['attribute_2'] . "X" . $filter['attribute_3'];
           
            $tempSize = str_replace(' ', '', $tempSize);
            if ($pid == $filter['product_id'] && $catId == $filter['category_id'] && $product_type == $filter['attribute_4'] && $finish == $filter['attribute_5'] && $size == $tempSize) {
                foreach ($this->productOptions as $option) {
                    if (!in_array(trim($filter['partnumber']), $keys) && $pid == $option['product_id'] && trim($option['title']) == trim($filter['partnumber'])) {
                        $keys[] = trim($filter['partnumber']);
                        $type=empty($filter['attribute_7'])?"default":$filter['attribute_7'];
                        $parts[] = ["types"=>$types[$type],"type"=>$type,"cat_id" => $filter['category_id'], "pid" => $option['product_id'], "id" => $option['option_type_id'], "title" => $option['title'],'min_qty'=>$filter['min_qty'] ,'qty_on_hand'=>$filter['qty_on_hand'],'status_type'=>$filter['status_type'] ,'price' => "Loading..."];
                    }
                }
            }
        }

        return $parts;
    }

    protected function getFilters($productIds, $searchQuery,$is_stocked) {
        $connection = $this->getConnection();
        $sql = "select * from laminart_product_description WHERE is_visible=1";
        if (count(array_unique($productIds)) > 1) {
            $sql .= " AND  product_id IN(" . implode(',', $productIds) . ")";
        } else {
            $temsql = "select * from laminart_product_description WHERE partnumber='" . trim($searchQuery) . "'";
            $result = $connection->fetchAll($temsql);
            if (count($result) > 0) {
                $sql .= " AND  product_id =" . $productIds[0] . " and attribute_4='" . $result[0]['attribute_4'] . "'"." and attribute_5='" . $result[0]['attribute_5'] . "'"." and attribute_2='" . $result[0]['attribute_2'] . "'"." and attribute_3='" . $result[0]['attribute_3'] . "'";
            } else {
                $sql .= " AND  product_id IN(" . implode(',', $productIds) . ")";
            }
        }
        if($is_stocked!='all_data'){
            $sql .= " AND (status_type = 's' OR (status_type = 'o' and qty_on_hand > 0 ) OR  (status_type = 'X' and qty_on_hand > 0))";
        }
       
        return $connection->fetchAll($sql);
    }

    protected function getOptions($productIds) {

        $connection = $this->getConnection();
        //  $sql        = "select * from catalog_product_option WHERE  product_id IN(".implode(',', $productIds).")";
        $sql = "select cpo.option_id,cpo.product_id,cpotv.option_type_id,cpott.title from catalog_product_option as cpo LEFT OUTER JOIN catalog_product_option_type_value as cpotv ON cpo.option_id=cpotv.option_id LEFT OUTER JOIN catalog_product_option_type_title as cpott  ON cpotv.option_type_id=cpott.option_type_id WHERE  cpo.product_id IN(" . implode(',', $productIds) . ")";
        // $options=$connection->fetchAll($sql);
        //$optionValueCollection=$this->optionValueCollectionFactory->create();
        //$optionValueCollection->addTitlesToResult(0);
        //$optionValueCollection ->addFieldToFilter('option_id', ['in' => $options]);
        return $connection->fetchAll($sql);
    }

}
