define(['jquery', 'mage/template', 'jquery/ui', 'mage/translate', "mage/mage"], function ($, mageTemplate) {


    ItemProcesser = {

        webServiceUrl: null,
        cutId: null,
        wareId: null,
        shipto: null,

        appendDialog: function () {

            var html = '<table class="table-bordered"><tr><th>Select</th>\
                                                                            <th class="tdGrayColor">Finish</th>\
                                                                            <th class="tdGrayColor">Size</th>\
                                                                            <th class="tdGrayColor">Product #</th>\
                                                                            <th class="tdGrayColor"> Qty in stock</th></tr>';

            html += '<tr><td><input type="radio" name="daiva"></td><td>--</td><td>--</td><td>--</td><td>--</td></tr>';
            html += '<tr><td><input type="radio" name="daiva"></td><td>--</td><td>--</td><td>--</td><td>--</td></tr>';
            html += '<tr><td><input type="radio" name="daiva"></td><td>--</td><td>--</td><td>--</td><td>--</td></tr>';

            html += '</table>';
            $('.table-conent').append(html);

        },

        appendProductType: function (item) {

            var self = this;
            var isFirst = true;
            if (Array.isArray(item.product_type) != true) {
                item.product_type = [item.product_type];
            }

            $.each(item.product_type, function (index, obj) {
                $("#product_type_" + obj.cat_id + "_" + obj.pid).append($('<option>', {
                    value: obj.id,
                    text: obj.title
                }));

                if (isFirst) {
                    self.appendFinish(obj, obj.cat_id, obj.pid, true);
                    $("#product_type_" + obj.cat_id + "_" + obj.pid).val($("#product_type_" + obj.cat_id + "_" + obj.pid + " option").eq(1).val());
                    $("#protype_option_" + obj.cat_id + "_" + obj.pid).val(obj.id);
                    isFirst = false;
                }

            });

        },

        appendFinish: function (item, cat_id, pid, isFirst) {

            var self = this;

            $("#finish_" + cat_id + "_" + pid).html('');
            $("#finish_" + cat_id + "_" + pid).attr("proTypeId", item.id);
            var opt = $('<option>', {
                disabled: true,
                value: null,
                text: "Finish"
            });
            $(opt).prop('selected', true);

            $("#finish_" + cat_id + "_" + pid).append(opt);


            /*if(Array.isArray(item.finish)!=true){
             item.finish=[item.finish];
             }*/
            $.each(item.finish, function (index, obj) {
                $("#finish_" + cat_id + "_" + obj.pid).append($('<option>', {
                    value: obj.id,
                    text: obj.title
                }));

                if (isFirst) {
                    self.appendSize(obj, cat_id, obj.pid, true);
                    $("#finish_" + cat_id + "_" + obj.pid).val($("#finish_" + cat_id + "_" + obj.pid + " option").eq(1).val());
                    $("#finish_option_" + cat_id + "_" + obj.pid).val(obj.id);
                    isFirst = false;
                }

            });

        },
        appendSize: function (item, cat_id, pid, isFirst) {
            var self = this;
            $("#size_" + cat_id + "_" + pid).html('');
            $("#size_" + cat_id + "_" + pid).attr("finishId", item.id);

            var opt = $('<option>', {
                disabled: true,
                value: null,
                text: "Size"
            });
            $(opt).prop('selected', true);


            $("#size_" + cat_id + "_" + pid).append(opt);
            $.each(item.sizes, function (index, obj) {

                $("#size_" + cat_id + "_" + pid).append($('<option>', {
                    value: obj.id,
                    text: obj.title
                }));
                if (isFirst) {
                    $("#size_option_" + cat_id + "_" + pid).val(obj.id);
                    $("#size_" + obj.cat_id + "_" + obj.pid).val($("#size_" + obj.cat_id + "_" + obj.pid + " option").eq(1).val());
                    self.appendPartNumber(obj, cat_id, pid);

                    isFirst = false;
                }
            });
        },
        appendPartNumber: function (item, cat_id, pid) {
            //console.log(item.part_no[0].title);
            var self = this;
            if (Array.isArray(item.part_no) != true) {
                item.part_no = [item.part_no];
            }
            $("#part_no_" + cat_id + "_" + pid).html("Loading...");

            $("#price_" + cat_id + "_" + pid).html("Loading...");
            $("#qty_available_" + cat_id + "_" + pid).html("Loading...");
            $("#qty_" + cat_id + "_" + pid).val("");
            // $('#price_loader_' + cat_id + "_" + pid).show();


            $.ajax({
                url: self.webServiceUrl,
                data: {"cutId": self.cutId, "part": encodeURIComponent(item.part_no[0].title), "qty": 1, "wareId": self.wareId, "shipto": self.shipto, "prodid": pid, "category_id": ""},
                type: "POST",
                success: function (result) {
                    //console.log(result);
                    var extPrice = parseFloat(result.extended_amount);
                    // $('#price_loader_' + pid).hide();
                    $("#part_no_" + cat_id + "_" + pid).html(item.part_no[0].title);
                    $("#part_option_" + cat_id + "_" + pid).val(item.part_no[0].id);
                    $("#price_" + cat_id + "_" + pid).html("$" + extPrice.toFixed(2));
                    $("#qty_available_" + cat_id + "_" + pid).html(result.net_available);
                    $("#qty_" + cat_id + "_" + pid).val(1);
                    $('#other_options_' + cat_id + "_" + pid).val(result.encrypted_price);
                    $("#imgWishList_" + cat_id + "_" + pid).show();
                    $("#imgCart_" + cat_id + "_" + pid).removeAttr('disabled', 'disabled');


                }
            });

        }

    };

    return function (values, node) {
        var productIds = values.productIds;

        var currentObj = {data: {}}
        var temp = {data: {}}
        var reqUrl = values.reqUrl;
        ItemProcesser.webServiceUrl = values.webServiceUrl;
        ItemProcesser.cutId = values.cutId;
        ItemProcesser.wareId = values.wareId;
        ItemProcesser.shipto = values.shipto;
        $.ajax({
            url: reqUrl, //the page containing php script
            data: {"pids": productIds, searchkeyword: values.searchKeyword},
            type: "POST", //request type
            showLoader: true,
            success: function (result) {
                window.wilsonartFilter = result;
                $.each(result, function (index, item) {
                    ItemProcesser.appendProductType(item);
                });
                //ItemProcesser.appendDialog();
                //  $(".productfinish").val($(".productfinish option").eq(1).val());
                // $(".productsize").val($(".productsize option").eq(1).val());
                //$(".tocart").removeAttr('disabled', 'disabled'); 


            }
        });


        $(".producttype").change(function () {

            var id = $(this).attr('id').split('_');
            var pid = id[1];

            $("#part_no_" + pid).html("");
            $("#imgCart_" + pid).attr('disabled', 'disabled');
            $("#qty_" + pid).val("");
            $("#price_" + pid).html("");
            $("#qty_available_" + pid).html("");
            var selectedValue = $(this).val();
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid)
                    return item;
            });
            $("#product_type_" + cat_id + "_" + pid).val(selectedValue);
            var proType = product.product_type.find(function (item) {
                if (item.id == selectedValue)
                    return item;
            });

            ItemProcesser.appendFinish(proType, pid, false);

        });

        $(".productfinish").change(function () {

            var id = $(this).attr('id').split('_');
            var pid = id[2];
            var cat_id = id[1];
            var proTypeId = $(this).attr("proTypeId");
            $("#part_no_" + cat_id + "_" + pid).html("");
            $("#qty_" + cat_id + "_" + pid).val("");
            $("#price_" + cat_id + "_" + pid).html("");
            $("#qty_available_" + cat_id + "_" + pid).html("");
            $("#imgCart_" + cat_id + "_" + pid).attr('disabled', 'disabled');
            $("#imgWishList_" + cat_id + "_" + pid).hide();

            var selectedValue = $(this).val();
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid && item.cat_id == cat_id)
                    return item;
            });
            var proType = product.product_type.find(function (item) {
                if (item.id == proTypeId)
                    return item;
            });
            $("#finish_option_" + cat_id + "_" + pid).val(selectedValue);
            var finish = proType.finish.find(function (item) {
                if (item.id == selectedValue)
                    return item;
            });

            ItemProcesser.appendSize(finish, cat_id, pid, false);

        });




        $(".productsize").change(function () {

            var id = $(this).attr('id').split('_');
            var pid = id[2];
            var cat_id = id[1];
            var selectedValue = $(this).val();
            var proTypeId = $("#finish_" + cat_id + "_" + pid).attr("proTypeId");
            $("#imgCart_" + cat_id + "_" + pid).attr('disabled', 'disabled');
            $("#imgWishList_" + cat_id + "_" + pid).hide();
            var finishId = $(this).attr("finishId");
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid && item.cat_id == cat_id)
                    return item;
            });
            var proType = product.product_type.find(function (item) {
                if (item.id == proTypeId)
                    return item;
            });
            var finish = proType.finish.find(function (item) {
                if (item.id == finishId)
                    return item;
            });
            $("#size_option_" + cat_id + "_" + pid).val(selectedValue);
            var size = finish.sizes.find(function (item) {
                if (item.id == selectedValue)
                    return item;
            });


            ItemProcesser.appendPartNumber(size, cat_id, pid);

        });

        $(".additionalItems").click(function () {

            console.log($(this).data("catPro"));
            var id = $(this).data("catPro").split('_');
            var pid = id[1];
            var cat_id = id[0];
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid && item.cat_id == cat_id)
                    return item;
            });
            console.log(product);
            var result = [];
            var i = 0;
            $.each(product.product_type, function (index, productType) {
                $.each(productType.finish, function (index, finish) {

                    $.each(finish.sizes, function (index, size) {
                        result[i++] = {itemId: pid + "_" + cat_id + "_" + productType.id + "_" + finish.id + "_" + size.id, productType: productType.title, finish: finish.title, size: size.title, part: size.part_no[0].title};
                        console.log(finish.title + "--" + size.title + "--" + size.part_no[0].title);
                    });

                });
            });
            currentObj.data = {filter: result};
            setTemplate(currentObj);

        });


        $(document).on("click", ".daiva", function () {
            var selectedVal = $("input[name='part']:checked").val();
            if (selectedVal) {
                var ids = selectedVal.split('_');
                var pid = ids[0];
                var cat_id = ids[1];
                var proTypeId = ids[2];
                var finishId = ids[3];
                var sizeId = ids[4];
                var part = ids[5];
                var product = window.wilsonartFilter.find(function (item) {
                    if (item.product_id == pid && item.cat_id == cat_id)
                        return item;
                });
                $("#product_type_" + cat_id + "_" + pid).val(proTypeId);
                var productType = product.product_type.find(function (item) {
                    if (item.id == proTypeId)
                        return item;
                });
                $("#product_type__option_" + cat_id + "_" + pid).val(proTypeId);

                $("#finish_" + cat_id + "_" + pid).val(finishId);
                var finish = productType.finish.find(function (item) {
                    if (item.id == finishId)
                        return item;
                });
                $("#finish_option_" + cat_id + "_" + pid).val(finishId);
                ItemProcesser.appendSize(finish, cat_id, pid, false);
                $("#size_" + cat_id + "_" + pid).val(sizeId);
                var size = finish.sizes.find(function (item) {
                    if (item.id == sizeId)
                        return item;
                });
                $("#size_option_" + cat_id + "_" + pid).val(sizeId);
                ItemProcesser.appendPartNumber(size, cat_id, pid);
            }
        });
        $(document).on("click", "#reset-model-search", function () {
            setTemplate(currentObj);
        });
        
        $(document).on("click", ".qty-show", function (e) {
            e.preventDefault();
            console.log(currentObj);
            
            $.each(currentObj.data.filter, function (index, item) {
                
                 var ids = item.itemId.split('_');
                var pid = ids[0];
                var cat_id = ids[1];
            
                
                $("#"+item.itemId).html("Loading...");
                 $.ajax({
                url: ItemProcesser.webServiceUrl,
                data: {"cutId": ItemProcesser.cutId, "part": encodeURIComponent(item.part), "qty": 1, "wareId": ItemProcesser.wareId, "shipto": ItemProcesser.shipto, "prodid": pid, "category_id": cat_id},
                type: "POST",
                success: function (result) {
                  
                    $("#"+item.itemId).html(""+result.net_available);

                }
            });
                
                setTimeout(function(){  }, 4000);
                
                    });
            
        });
        
        $(document).on("keyup", "#pattern_avaliablity_input", function () {
            var str = this.value;
            var result = currentObj.data.filter.filter(function (i) {

                if (i.part.indexOf(str) >= 0)
                    return true;
            });
            //console.log(temp);
            temp.data = {filter: result};
            console.log(temp);
            setTemplate(temp);
        });

        function setTemplate(xx) {
            var progressTmpl = mageTemplate('#filter-template'), tmpl;
            tmpl = progressTmpl(xx);
            $('#table-conent').html(tmpl);
        }

    };

});