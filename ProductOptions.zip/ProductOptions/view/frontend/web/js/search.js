define(['jquery', 'mage/template','Magento_Customer/js/customer-data', 'jquery/ui', 'mage/translate', "mage/mage",], function ($, mageTemplate, customerData) {


    ItemProcesser = {

        webServiceUrl: null,
        cutId: null,
        wareId: null,
        shipto: null,
        products: [],

        appendDialog: function () {

            var html = '<table class="table-bordered"><tr><th>Select</th>\
                <th class="tdGrayColor">Finish</th>\
                <th class="tdGrayColor">Size</th>\
                <th class="tdGrayColor">Product #</th>\
                 <th class="tdGrayColor"> Qty in stock</th></tr>';

            html += '<tr><td><input type="radio" name="daiva"></td><td>--</td><td>--</td><td>--</td><td>--</td></tr>';
            html += '<tr><td><input type="radio" name="daiva"></td><td>--</td><td>--</td><td>--</td><td>--</td></tr>';
            html += '<tr><td><input type="radio" name="daiva"></td><td>--</td><td>--</td><td>--</td><td>--</td></tr>';

            html += '</table>';
            $('.table-conent').append(html);

        },
        
        
        appendFilter: function (item, ele) {

           
            if (Array.isArray(item) != true) {
                item = [item];
            }

            $.each(item, function (index, obj) {
                ele.append($('<option>', {
                    value: obj.title,
                    text: obj.title
                }));


            });

        },

        appendProductType: function (item) {

            var self = this;
            var isFirst = true;
            if (Array.isArray(item.product_type) != true) {
                item.product_type = [item.product_type];
            }

            $.each(item.product_type, function (index, obj) {
                $("#producttype_" + obj.cat_id + "_" + obj.pid).append($('<option>', {
                    value: obj.id,
                    text: obj.title
                }));
                if(filterProductType){
                    if(filterProductType==obj.title){
                    $("#producttype_" + obj.cat_id + "_" + obj.pid).val(obj.id).change();
                    filterProductType='';
                }
                }else{
                if (isFirst) {
                    self.appendFinish(obj, obj.cat_id, obj.pid, true);
                    $("#producttype_" + obj.cat_id + "_" + obj.pid).val($("#producttype_" + obj.cat_id + "_" + obj.pid + " option").eq(1).val());
                    $("#protype_option_" + obj.cat_id + "_" + obj.pid).val(obj.id);
                    isFirst = false;
                }
            }

            });

        },

        appendFinish: function (item, cat_id, pid, isFirst) {

            var self = this;
            $('#exactqty_available_data_'+ cat_id + "_" + pid).hide();
            $("#finish_" + cat_id + "_" + pid).html('');
            $("#finish_" + cat_id + "_" + pid).attr("proTypeId", item.id);
            var opt = $('<option>', {
                disabled: true,
                value: null,
                text: "Finish"
            });
            $(opt).prop('selected', true);

            $("#finish_" + cat_id + "_" + pid).append(opt);


            $("#size_" + cat_id + "_" + pid).html('');

            var opt = $('<option>', {
                disabled: true,
                value: null,
                text: "Size"
            });
            $(opt).prop('selected', true);


            $("#size_" + cat_id + "_" + pid).append(opt);

            /*if(Array.isArray(item.finish)!=true){
             item.finish=[item.finish];
             }*/
            $.each(item.finish, function (index, obj) {
                $("#finish_" + cat_id + "_" + obj.pid).append($('<option>', {
                    value: obj.id,
                    text: obj.title
                }));
                
                if(filterFinish){
                    if(filterFinish==obj.title){
                    $("#finish_" + obj.cat_id + "_" + obj.pid).val(obj.id).change();
                    filterFinish='';
                }
                }else{
                if (isFirst) {
                    self.appendSize(obj, cat_id, obj.pid, true);
                    $("#finish_" + cat_id + "_" + obj.pid).val($("#finish_" + cat_id + "_" + obj.pid + " option").eq(1).val());
                    $("#finish_option_" + cat_id + "_" + obj.pid).val(obj.id);
                    isFirst = false;
                }
            }
            });

        },
        appendSize: function (item, cat_id, pid, isFirst) {
            var self = this;
            $('#exactqty_available_data_'+ cat_id + "_" + pid).hide();
            $("#size_" + cat_id + "_" + pid).html('');
            $("#size_" + cat_id + "_" + pid).attr("finishId", item.id);

            var opt = $('<option>', {
                disabled: true,
                value: null,
                text: "Size"
            });
            $(opt).prop('selected', true);


            $("#size_" + cat_id + "_" + pid).append(opt);
            $.each(item.sizes, function (index, obj) {

                $("#size_" + cat_id + "_" + pid).append($('<option>', {
                    value: obj.id,
                    text: obj.title
                }));
                
                
                if(filterSize){
                    if(filterSize==obj.title){
                    $("#size_" + obj.cat_id + "_" + obj.pid).val(obj.id).change();
                    filterSize='';
                }
                }else{
                
                if (isFirst) {
                    $("#size_option_" + cat_id + "_" + pid).val(obj.id);
                    $("#size_" + obj.cat_id + "_" + obj.pid).val($("#size_" + obj.cat_id + "_" + obj.pid + " option").eq(1).val());
                    self.appendPartNumber(obj, cat_id, pid, "default", true);

                    isFirst = false;
                }
            }
            });
        },
        appendPartNumber: function (item, cat_id, pid, type = "default", isFirst = false) {

            
            var self = this;
             if (Array.isArray(item.part_no) != true) {
               item.part_no = [item.part_no];
             }
             
             $(".part_type_td").hide();
             $('#radio-container_'+cat_id+'_'+pid).hide();
             $(".parttype").prop('checked', false);
             
            if (isFirst==true && item.part_no.length>1) {
                if(item.part_no.length==2){
                    $(".radio-container").css('padding-left','150px');
                }else{
                    $(".radio-container").css('padding-left','');
                }
                //$('.part_type_td').show();
                console.log(item.part_no);
                
               
                var matchedPart = item.part_no.find(function (obj) {
                    if (obj.title.trim() ==  window.searchedOne.trim())
                        return true;

                });
                
                if(matchedPart!=undefined){
                    
                    $.each(item.part_no, function (index, obj) {
                    if (obj.type == matchedPart.type){
                        if(matchedPart.type!='default'){
                         $("#" + obj.type + "_" + cat_id + "_" + pid).prop('checked', true); 
                    }
                        self.processData(cat_id, pid, obj);
                    }
                    var value = cat_id + "_" + pid + "_" + obj.title+ "_" + obj.id;
                    
                    $("#" + obj.type + "_" + cat_id + "_" + pid).val(value);
                    $("#td_" + obj.type + "_" + cat_id + "_" + pid).show();


                });
                    
                }
                else{
                
                $.each(item.part_no, function (index, obj) {
                    if (obj.type == "default")
                        self.processData(cat_id, pid, obj);

                    var value = cat_id + "_" + pid + "_" + obj.title+ "_" + obj.id;
                    
                    $("#" + obj.type + "_" + cat_id + "_" + pid).val(value);
                    $("#td_" + obj.type + "_" + cat_id + "_" + pid).show();


                });
            }
            } else {
                var result = item.part_no[0];
                 

        if(item.part_no.length>1){
            result = item.part_no.find(function (obj) {
                    if (obj.type == type)
                        return true;

                });
                $.each(item.part_no, function (index, obj) {

                    var value = cat_id + "_" + pid + "_" + obj.title;
                    if(isFirst=='daiva' && result.type==obj.type && type!='default'){
                       $("#" + obj.type + "_" + cat_id + "_" + pid).prop('checked', true); 
                    }
                    $("#" + obj.type + "_" + cat_id + "_" + pid).val(value);
                    $("#td_" + obj.type + "_" + cat_id + "_" + pid).show();


                });
        }

                
                self.processData(cat_id, pid, result);
        }

        },

        processData: function (cat_id, pid, partNumber) {
            var self = this;
            $('#exactqty_available_data_'+ cat_id + "_" + pid).hide();
            $("#part_no_" + cat_id + "_" + pid).html("Loading...");
             $('#product_avaliable_'+ cat_id+'_'+pid).html("Loading...");
            $("#imgCart_" + cat_id + "_" + pid).attr('disabled', 'disabled');
            $("#imgWishList_" + cat_id + "_" + pid).hide();
            $("#price_" + cat_id + "_" + pid).html("Loading...");
            $("#qty_available_" + cat_id + "_" + pid).html("Loading...");
            $("#qty_" + cat_id + "_" + pid).val("");
            $("#part_no_" + cat_id + "_" + pid).html(partNumber.title);
             $("#part_option_" + cat_id + "_" + pid).val(partNumber.id);
            $.ajax({
                url: self.webServiceUrl,
                data: {"cutId": self.cutId, "part": encodeURIComponent(partNumber.title), "qty": 1, "wareId": self.wareId, "shipto": self.shipto, "prodid": pid, "category_id": ""},
                type: "POST",
                success: function (result) {
                    //console.log(result);
                    var ex = -1;
                    $.each(self.products, function (index, item) {
                        if (item.proid == cat_id + "_" + pid) {
                            ex = index;
                        }
                    });
                    if (ex >= 0) {
                        self.products.splice(ex, 1);
                    }
                    self.products.push({"proid": cat_id + "_" + pid, "result": result});
                    var extPrice = parseFloat(result.extended_amount);
                    // $('#price_loader_' + pid).hide();
                    console.log(partNumber.title);
                    $('#exactqty_available_data_'+ cat_id + "_" + pid).show();
                    $('#radio-container_'+cat_id+'_'+pid).show();
                    console.log("#part_no_" + cat_id + "_" + pid);
                    $('.product_status_data_' + cat_id + "_" + pid).show();
                    $("#part_no_" + cat_id + "_" + pid).html(partNumber.title);
                    $("#part_option_" + cat_id + "_" + pid).val(partNumber.id);
                    var customer = customerData.get('customer');
                    if(!customer().firstname)
                        $("#price_" + cat_id + "_" + pid).html("");
                    else
                        $("#price_" + cat_id + "_" + pid).html("$" + extPrice.toFixed(2));
                    $("#qty_available_" + cat_id + "_" + pid).html(result.net_available);
                    if(partNumber.min_qty=='' || isNaN(partNumber.min_qty) || partNumber.min_qty<1){
                        $("#qty_" + cat_id+'_'+pid).val(1);
                        $('#min_qty_'+ cat_id+'_'+pid).val(1);
                    }else{
                       $("#qty_" + cat_id+'_'+pid).val(partNumber.min_qty);
                    $('#min_qty_'+ cat_id+'_'+pid).val(partNumber.min_qty); 
                    }
                    $('#product_avaliable_'+ cat_id+'_'+pid).html(result.final_available_soon);

                    $('#status_type_'+ cat_id+'_'+pid).val(partNumber.status_type);
                    $('#qty_on_hand_'+ cat_id+'_'+pid).val(partNumber.qty_on_hand);
                    $('#other_options_' + cat_id + "_" + pid).val(result.encrypted_price);
                    if(extPrice.toFixed(2)>0){
                        $("#imgWishList_" + cat_id + "_" + pid).show();
                        $("#imgCart_" + cat_id + "_" + pid).removeAttr('disabled', 'disabled');
                    }


                }
            });
        }

    };

    return function (values, node) {
        var productIds = values.productIds;
        window.searchedOne=values.searchKeyword;
        if(productIds.length<1){
            $('.loading-mask').hide();
            return;
        }
        var currentObj = {data: {}};
        var temp = {data: {}};
        var currentItem={pid:null,cid:null};
        var reqUrl = values.reqUrl;
        ItemProcesser.webServiceUrl = values.webServiceUrl;
        ItemProcesser.cutId = values.cutId;
        ItemProcesser.wareId = values.wareId;
        ItemProcesser.shipto = values.shipto;
        $.ajax({
            url: reqUrl, //the page containing php script
            data: {"pids": productIds, searchkeyword: values.searchKeyword, is_stocked: values.isStocked},
            type: "POST", //request type
            
            success: function (result) {
                $('.loading-mask').hide();
                window.wilsonartFilter = result;

                $.each(result, function (index, item) {
                    ItemProcesser.appendProductType(item);
                });

            }
        });
        
        
         $(".filterCategory").change(function () {
            var cat_id = $(this).val();
             $('.filterProducttypes').attr("disabled", false);
             $('.filterProducttypes').css("background-color", '');
            $('.filterProductfinish').attr("disabled", true);
            $('.filterProductfinish').css("background-color", '#eee');
             $('.filterProductsize').attr("disabled", true);
             $('.filterProductsize').css("background-color", '#eee');
            var product = window.wilsonartFilter.find(function (item) {
                if (item.cat_id == cat_id)
                    return item;
            });
            
            var opt1=$('<option>', {
                               disabled: true,
                               value: null,
                               text: "Product Type"
                           });
			$(opt1).prop('selected',true);
                        $(".filterProducttypes").html('');
                            $(".filterProducttypes").append(opt1);
            
            ItemProcesser.appendFilter(product.product_type,$(".filterProducttypes"));

        });
        
        
        
        $(".filterProducttypes").change(function () {
            $('.filterProductfinish').attr("disabled", false);
            $('.filterProductfinish').css("background-color", '');
            $('.filterProductsize').attr("disabled", true);
            $('.filterProductsize').css("background-color", '#eee');
            
            var cat_id = $(".filterCategory").val();
      
            var product = window.wilsonartFilter.find(function (item) {
                if (item.cat_id == cat_id)
                    return item;
            });
            var type_id = $(this).val();
     
            var productFinish = product.product_type.find(function (item) {
                if (item.title == type_id)
                    return item;
            });
            
            var opt1=$('<option>', {
                               disabled: true,
                               value: null,
                               text: "Finish"
                           });
			$(opt1).prop('selected',true);
                        $(".filterProductfinish").html('');
                            $(".filterProductfinish").append(opt1);
            
            ItemProcesser.appendFilter(productFinish.finish,$(".filterProductfinish"));

        });
        
        $(".filterProductfinish").change(function () {
            
            $('.filterProductsize').attr("disabled", false);
            $('.filterProductsize').css("background-color", '');
            var cat_id = $(".filterCategory").val();
            
            var product = window.wilsonartFilter.find(function (item) {
                if (item.cat_id == cat_id)
                    return item;
            });
            var type_id = $(".filterProducttypes").val();
     
            var productFinish = product.product_type.find(function (item) {
                if (item.title == type_id)
                    return item;
            });
            
            var finsh_id = $(this).val();
     
            var productSize = productFinish.finish.find(function (item) {
                if (item.title == finsh_id)
                    return item;
            });
            
            var opt1=$('<option>', {
                               disabled: true,
                               value: null,
                               text: "Size"
                           });
			$(opt1).prop('selected',true);
                        $(".filterProductsize").html('');
                            $(".filterProductsize").append(opt1);
            
            ItemProcesser.appendFilter(productSize.sizes,$(".filterProductsize"));

        });


        $(".producttype").change(function () {

            var id = $(this).attr('id').split('_');
            var pid = id[2];
            var cat_id = id[1];
            
            $("#part_no_" + cat_id + "_" + pid).html("");
            $("#qty_" + cat_id + "_" + pid).val("");
            $("#price_" + cat_id + "_" + pid).html("");
            $("#qty_available_" + cat_id + "_" + pid).html("");
            $("#imgCart_" + cat_id + "_" + pid).attr('disabled', 'disabled');
            $("#imgWishList_" + cat_id + "_" + pid).hide();
             $('.part_type_td').hide();
            
            var selectedValue = $(this).val();
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid)
                    return item;
            });
            $("#protype_option_" + cat_id + "_" + pid).val(selectedValue);
            $("#finish_" + cat_id + "_" + pid).attr("proTypeId", selectedValue);
            var proType = product.product_type.find(function (item) {
                if (item.id == selectedValue)
                    return item;
            });

            ItemProcesser.appendFinish(proType,cat_id, pid, false);

        });

        $(".productfinish").change(function () {

            var id = $(this).attr('id').split('_');
            var pid = id[2];
            var cat_id = id[1];
            var proTypeId = $(this).attr("proTypeId");
            $("#part_no_" + cat_id + "_" + pid).html("");
            $("#qty_" + cat_id + "_" + pid).val("");
            $("#price_" + cat_id + "_" + pid).html("");
            $("#qty_available_" + cat_id + "_" + pid).html("");
            $("#imgCart_" + cat_id + "_" + pid).attr('disabled', 'disabled');
            $("#imgWishList_" + cat_id + "_" + pid).hide();
             $('.part_type_td').hide();
            var selectedValue = $(this).val();
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid && item.cat_id == cat_id)
                    return item;
            });
            var proType = product.product_type.find(function (item) {
                if (item.id == proTypeId)
                    return item;
            });
            $("#finish_option_" + cat_id + "_" + pid).val(selectedValue);
            var finish = proType.finish.find(function (item) {
                if (item.id == selectedValue)
                    return item;
            });

            ItemProcesser.appendSize(finish, cat_id, pid, false);

        });




        $(".productsize").change(function () {

            var id = $(this).attr('id').split('_');
            var pid = id[2];
            var cat_id = id[1];
            var selectedValue = $(this).val();
            var proTypeId = $("#finish_" + cat_id + "_" + pid).attr("proTypeId");
            $("#imgCart_" + cat_id + "_" + pid).attr('disabled', 'disabled');
            $("#imgWishList_" + cat_id + "_" + pid).hide();
             $('.part_type_td').hide();
            var finishId = $(this).attr("finishId");
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid && item.cat_id == cat_id)
                    return item;
            });
            var proType = product.product_type.find(function (item) {
                if (item.id == proTypeId)
                    return item;
            });
            var finish = proType.finish.find(function (item) {
                if (item.id == finishId)
                    return item;
            });
            $("#size_option_" + cat_id + "_" + pid).val(selectedValue);
            var size = finish.sizes.find(function (item) {
                if (item.id == selectedValue)
                    return item;
            });


            ItemProcesser.appendPartNumber(size, cat_id, pid, "default", true);

        });


        $(".exactQtydetails").click(function () {
            var pid = jQuery(this).attr('data-rel-id');
            jQuery("#netAvailQtyOnStock").text('Loading...');
            jQuery("#qtyAvailQtyOnOrder").text('Loading...');
            jQuery("#qtyAvailQtyOnBackOrder").text('Loading...');
            jQuery("#exactAvailQtyOnStock").text('Loading...');
            jQuery("#exactAvailDateLabel1, #exactAvailDate1").hide();
            jQuery("#availability-msg").hide(); 
             var part = $("#part_no_" + pid).text();   //'LP-10599089149BJ145BJ'; //jQuery("#part-number").text();                        

             jQuery("#exactAvailPart").text(part);
                var webservicedata = ItemProcesser.products.find(function (obj) {
                    console.log(obj.pro_id);
                    if (obj.proid == pid)
                        return true;
                });

                console.log(webservicedata.result);
                var net_available_exact=webservicedata.result.net_available_exact==null?0:webservicedata.result.net_available_exact
                var quantity_on_order=webservicedata.result.quantity_on_order==null?0:webservicedata.result.quantity_on_order;
                var quantity_backorder=webservicedata.result.quantity_backorder==null?0:webservicedata.result.quantity_backorder;
                var finalqty =  quantity_on_order - quantity_backorder;
                //jQuery("#exactAvailPart").text(part_number);
                
                jQuery("#netAvailQtyOnStock").text(net_available_exact);
                jQuery("#exactAvailQtyOnStock").text(finalqty);
                jQuery("#qtyAvailQtyOnOrder").text(quantity_on_order);
                jQuery("#qtyAvailQtyOnBackOrder").text(quantity_backorder);
                if(webservicedata.result.available_date != '' && webservicedata.result.available_date!=null){
                    jQuery("#exactAvailDateLabel1, #exactAvailDate1").show();
                    var finaldate = webservicedata.result.available_date.split(",");
                    if(finaldate.length>1){
                      jQuery("#availability-msg").show();  
                    }
                    jQuery("#exactAvailDate1").html('');
                    jQuery.each( finaldate, function( i, val ) {
                        var avldate = jQuery("#exactAvailDate1").html();
                        jQuery("#exactAvailDate1").html(avldate+val+"<br/>");
                    });
                    //jQuery("#exactAvailDate").text(data[3]);
                }

            
        });



        jQuery(".viewPrice").click(function () {
            var pid = jQuery(this).attr('data-rel-id');
            jQuery("#popupPartnumber").text('');
            jQuery("#exactAvailDateLabel, #exactAvailDate").hide();
            jQuery("#uom").text('');
            jQuery("#priceProductName").text('');
            jQuery("#inforPricereal").text('');
            jQuery("#inforQty").text('');
            jQuery("#inforFinalPrice").text('');
            var qty = $("#qty_" + pid).val();
            if (qty == '') {
                alert("Please enter QTY");
                return false;
            } else {
                var part = $("#part_no_" + pid).text();   //'LP-10599089149BJ145BJ'; //jQuery("#part-number").text();                        


                console.log(ItemProcesser.products);
                var webservicedata = ItemProcesser.products.find(function (obj) {
                    console.log(obj.pro_id);
                    if (obj.proid == pid)
                        return true;
                });

                console.log(webservicedata.result);
                var unitPrice = parseFloat(webservicedata.result.price);
                var finalPrice = parseFloat(webservicedata.result.extended_amount);

                jQuery("#inforPrice").text("$" + unitPrice.toFixed(2));
                var finalPrice = finalPrice * qty;
                jQuery("#inforFinalPrice").text("$" + finalPrice.toFixed(2));

                jQuery("#uom").text(webservicedata.result.price_cost_per);
                jQuery("#popupPartnumber").text(part);
                jQuery("#inforQty").text(qty);
                if(webservicedata.result.available_date != '' && webservicedata.result.available_date!=null){
                   // jQuery("#exactAvailDateLabel, #exactAvailDate").show();
                    var finaldate = webservicedata.result.available_date.split(",");
                    jQuery("#exactAvailDate").html('');
                    jQuery.each( finaldate, function( i, val ) {
                        var avldate = jQuery("#exactAvailDate").html();
                        jQuery("#exactAvailDate").html(avldate+val+"<br/>");
                    });
                    //jQuery("#exactAvailDate").text(data[3]);
                }

            }
        });



        $(".additionalItems").click(function () {

            var id = $(this).data("catPro").split('_');
            var pid = id[1];
            var cat_id = id[0];
            if(currentItem.pid!=pid && currentItem.cid!=cat_id){
                currentItem.pid=pid;
                currentItem.cid=cat_id;
            }
            else{
                $(".daiva").prop('checked', false);
                return;
            }
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid && item.cat_id == cat_id)
                    return item;
            });
            var result = [];
            var i = 0;
            $.each(product.product_type, function (index, productType) {
                $.each(productType.finish, function (index, finish) {

                    $.each(finish.sizes, function (index, size) {
                        $.each(size.part_no, function (index, part_no) {
                            console.log(part_no);
                            result[i++] = {type:part_no.types,itemId: pid + "_" + cat_id + "_" + productType.id + "_" + finish.id + "_" + size.id + "_" + part_no.type, productType: productType.title, finish: finish.title, size: size.title, part: part_no.title};

                        });

                    });

                });
            });
            console.log(result);
            currentObj.data = {filter: result};
            setTemplate(currentObj);

        });
        $(document).on("click", ".parttype", function () {
            var selectedVal = $("input[name='parttype']:checked").val();
            if (selectedVal) {
                var ids = selectedVal.split('_');
                var pid = ids[1];
                var cat_id = ids[0];
                var partNumber = ids[2];
                var partNumberId = ids[3];
                ;

                ItemProcesser.processData(cat_id, pid, {id:partNumberId,title: partNumber});
            }
        });

        $(document).on("click", ".daiva", function () {
            $('#model-close-btn').trigger('click');
            var selectedVal = $("input[name='part']:checked").val();
            if (selectedVal) {
                var ids = selectedVal.split('_');
                var pid = ids[0];
                var cat_id = ids[1];
                var proTypeId = ids[2];
                var finishId = ids[3];
                var sizeId = ids[4];
                var partType = ids[5];
                var product = window.wilsonartFilter.find(function (item) {
                    if (item.product_id == pid && item.cat_id == cat_id)
                        return item;
                });
                $("#producttype_" + cat_id + "_" + pid).val(proTypeId);
                var productType = product.product_type.find(function (item) {
                    if (item.id == proTypeId)
                        return item;
                });
                $("#producttype__option_" + cat_id + "_" + pid).val(proTypeId);
                ItemProcesser.appendFinish(productType,cat_id, pid, false);
                $("#finish_" + cat_id + "_" + pid).val(finishId);
                var finish = productType.finish.find(function (item) {
                    if (item.id == finishId)
                        return item;
                });
                $("#finish_option_" + cat_id + "_" + pid).val(finishId);
                ItemProcesser.appendSize(finish, cat_id, pid, false);
                $("#size_" + cat_id + "_" + pid).val(sizeId);
                var size = finish.sizes.find(function (item) {
                    if (item.id == sizeId)
                        return item;
                });
                $("#size_option_" + cat_id + "_" + pid).val(sizeId);
               
                ItemProcesser.appendPartNumber(size, cat_id, pid, partType,'daiva');
            }
        });
        $(document).on("click", "#reset-model-search", function () {
           
            setTemplate(currentObj);
        });

        $(document).on("click", ".qty-show", function (e) {
            e.preventDefault();
            console.log(currentObj);

            $.each(currentObj.data.filter, function (index, item) {

                var ids = item.itemId.split('_');
                var pid = ids[0];
                var cat_id = ids[1];


                $("#" + item.itemId).html("Loading...");
                $.ajax({
                    url: ItemProcesser.webServiceUrl,
                    data: {"cutId": ItemProcesser.cutId, "part": encodeURIComponent(item.part), "qty": 1, "wareId": ItemProcesser.wareId, "shipto": ItemProcesser.shipto, "prodid": pid, "category_id": cat_id},
                    
                    success: function (result) {

                        $("#" + item.itemId).html("" + result.net_available);

                    }
                });

                setTimeout(function () { }, 4000);

            });

        });

        $(document).on("keyup", "#pattern_avaliablity_input", function () {
            var str = this.value;
            var result = currentObj.data.filter.filter(function (i) {

                if (i.part.indexOf(str) >= 0)
                    return true;
            });
            //console.log(temp);
            temp.data = {filter: result};
            console.log(temp);
            setTemplate(temp);
        });

        function setTemplate(xx) {
            var progressTmpl = mageTemplate('#filter-template'), tmpl;
            tmpl = progressTmpl(xx);
            $('#table-conent').html(tmpl);
        }

    };

});