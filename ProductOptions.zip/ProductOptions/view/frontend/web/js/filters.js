define(['jquery','Magento_Customer/js/customer-data', 'mage/template', 'underscore','jquery/ui', 'mage/translate'], function ($, customerData,mageTemplate,_) {


    ItemProcesser = {

        webServiceUrl: null,
        cutId: null,
        wareId: null,
        shipto: null,

        appendProductType: function (item) {

            var self = this;
            var isFirst = true;
            if (Array.isArray(item.product_type) != true) {
                item.product_type = [item.product_type];
            }

            $.each(item.product_type, function (index, obj) {
                $("#product_type_" + obj.pid).append($('<option>', {
                    value: obj.id,
                    text: obj.title
                }));

                if (isFirst) {
                    self.appendFinish(obj, obj.pid, true);
                    $("#product_type_" + obj.pid).val($("#product_type_" + obj.pid + " option").eq(1).val());
                    $("#finish_option_" + obj.pid).val(obj.id);
                    isFirst = false;
                }

            });

        },

        appendFinish: function (item, pid, isFirst) {

            var self = this;

            $("#finish_" + pid).html('');
            $("#finish_" + pid).attr("proTypeId", item.id);
            var opt = $('<option>', {
                disabled: true,
                value: null,
                text: "Finish"
            });
            $(opt).prop('selected', true);

            $("#finish_" + pid).append(opt);


            /*if(Array.isArray(item.finish)!=true){
             item.finish=[item.finish];
             }*/
            $.each(item.finish, function (index, obj) {
                $("#finish_" + obj.pid).append($('<option>', {
                    value: obj.id,
                    text: obj.title
                }));

                if (isFirst) {
                    self.appendSize(obj, obj.pid, true);
                    $("#finish_" + obj.pid).val($("#finish_" + obj.pid + " option").eq(1).val());
                    $("#finish_option_" + obj.pid).val(obj.id);
                    isFirst = false;
                }

            });

        },
        appendSize: function (item, pid, isFirst) {
            var self = this;
            $("#size_" + pid).html('');
            $("#size_" + pid).attr("finishId", item.id);
            var opt = $('<option>', {
                disabled: true,
                value: null,
                text: "Size"
            });
            $(opt).prop('selected', true);

            $("#size_" + pid).append(opt);
            $.each(item.sizes, function (index, obj) {

                $("#size_" + pid).append($('<option>', {
                    value: obj.id,
                    text: obj.title
                }));
                if (isFirst) {
                    $("#size_option_" + pid).val(obj.id);
                    $("#size_" + obj.pid).val($("#size_" + obj.pid + " option").eq(1).val());
                    self.appendPartNumber(obj, pid);

                    isFirst = false;
                }
            });
        },
        appendPartNumber: function (item, pid,type = "default",) {
            //console.log(item.part_no[0].title);
            var self = this;
            if (Array.isArray(item.part_no) != true) {
                item.part_no = [item.part_no];
            }
            var detecteditem=item.part_no[0];
            if(item.part_no.length>1){
            detecteditem=_.find(item.part_no,function(obj){
                return obj.type==type;
            });
            }
           self.processData(pid,detecteditem);

        }
        ,
        processData: function ( pid, partNumber) {
            var self = this;
             $("#part_no_" + pid).html("Loading...");
            
            $("#price_" + pid).html("Loading...");
            $("#qty_available_" + pid).html("Loading...");
            $("#qty_" + pid).val("");
            $('#price_loader_' + pid).show();
            $.ajax({
                url: self.webServiceUrl,
                data: {"cutId": self.cutId, "part": encodeURIComponent(partNumber.title), "qty": 1, "wareId": self.wareId, "shipto": self.shipto, "prodid": pid, "category_id": ""},
                type: "POST",
                success: function (result) {
            
                    var extPrice = parseFloat(result.extended_amount);
                    $('#price_loader_' + pid).hide();
                    $("#part_no_" + pid).html(partNumber.title);
                    $("#part_option_" + pid).val(partNumber.id);
                    
                    var customer = customerData.get('customer');
                    if(!customer().firstname)
                        $(".listpage-price").hide();
                    else
                        $("#price_" + pid).html("$" + extPrice.toFixed(2));
                    
                    
                    $("#qty_available_" + pid).html(result.net_available);
                    if(partNumber.min_qty=='' || isNaN(partNumber.min_qty) || partNumber.min_qty<1){
                        $("#qty_" + pid).val(1);
                        $('#min_qty_'+ pid).val(1);
                    }else{
                       $("#qty_" + pid).val(partNumber.min_qty);
                    $('#min_qty_'+ pid).val(partNumber.min_qty); 
                    }
                    $('#status_type_'+ pid).val(partNumber.status_type);
                    $('#qty_on_hand_'+ pid).val(partNumber.qty_on_hand);
                    
                    $('#other_options_'+pid).val(result.encrypted_price);
                    $("#imgCart_" + pid).removeAttr('disabled', 'disabled');


                }
            });

        }

    };

    return function (values, node) {
        var productIds = values.productIds;

        var reqUrl = values.reqUrl;
        var currentItem={pid:null,cid:null};
        
        var currentObj = {data: {}};
        var temp = {data: {}};
        ItemProcesser.webServiceUrl = values.webServiceUrl;
        ItemProcesser.cutId = values.cutId;
        ItemProcesser.wareId = values.wareId;
        ItemProcesser.shipto = values.shipto;
        if(values.status_type=='all'){
           values.status_type='all_data'; 
        }
        $.ajax({
            url: reqUrl, //the page containing php script
            data: {"pids": productIds,is_stocked:values.status_type},
            type: "POST", //request type
            showLoader: true,
            success: function (result) {
                window.wilsonartFilter = result;
                $.each(result, function (index, item) {
                    ItemProcesser.appendProductType(item);
                });
                //  $(".productfinish").val($(".productfinish option").eq(1).val());
                // $(".productsize").val($(".productsize option").eq(1).val());
                //$(".tocart").removeAttr('disabled', 'disabled'); 


            }
        });

        $(".producttype").change(function () {

            var id = $(this).attr('id').split('_');
            var pid = id[1];

            $("#part_no_" + pid).html("");
            $("#imgCart_" + pid).attr('disabled', 'disabled');
            $("#qty_" + pid).val("");
            $("#price_" + pid).html("");
            $("#qty_available_" + pid).html("");
            var selectedValue = $(this).val();
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid)
                    return item;
            });
            var proType = product.product_type.find(function (item) {
                if (item.id == selectedValue)
                    return item;
            });

            ItemProcesser.appendFinish(proType, pid, false);

        });


        $(".productfinish").change(function () {

            var id = $(this).attr('id').split('_');
            var pid = id[1];
            var proTypeId = $(this).attr("proTypeId");
            $("#part_no_" + pid).html("");
            $("#imgCart_" + pid).attr('disabled', 'disabled');
            $("#qty_" + pid).val("");
            $("#price_" + pid).html("");
            $("#qty_available_" + pid).html("");
            var selectedValue = $(this).val();
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid)
                    return item;
            });

            var proType = product.product_type.find(function (item) {
                if (item.id == proTypeId)
                    return item;
            });
            var finish = proType.finish.find(function (item) {
                if (item.id == selectedValue)
                    return item;
            });

            ItemProcesser.appendSize(finish, pid, false);

        });
        $(".productsize").change(function () {

            var id = $(this).attr('id').split('_');
            var pid = id[1];
            $("#imgCart_" + pid).attr('disabled', 'disabled');
            var selectedValue = $(this).val();
            var proTypeId = $("#finish_" + pid).attr("proTypeId");
            var finishId = $(this).attr("finishId");
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid)
                    return item;
            });
            var proType = product.product_type.find(function (item) {
                if (item.id == proTypeId)
                    return item;
            });
            var finish = proType.finish.find(function (item) {
                if (item.id == finishId)
                    return item;
            });

            var size = finish.sizes.find(function (item) {
                if (item.id == selectedValue)
                    return item;
            });


            ItemProcesser.appendPartNumber(size, pid);

        });
        
        
        

        $(".additionalItems").click(function () {
            $("#getPatternAvaliablity").appendTo("body");
            console.log($(this).data("catPro"));
            var id = $(this).data("catPro").split('_');
            var pid = id[1];
            var cat_id = id[0];
            
            if(currentItem.pid!=pid ){
                console.log(pid);
            console.log(cat_id);
                currentItem.pid=pid;
                currentItem.cid=cat_id;
            }
            else{
                $(".daiva").prop('checked', false);
                return;
            }
            var product = window.wilsonartFilter.find(function (item) {
                if (item.product_id == pid && item.cat_id == cat_id)
                    return item;
            });
            console.log(product);
            var result = [];
            var i = 0;
            $.each(product.product_type, function (index, productType) {
                $.each(productType.finish, function (index, finish) {

                    $.each(finish.sizes, function (index, size) {
                        $.each(size.part_no, function (index, part_no) {
                            
                            result[i++] = {type:part_no.types,itemId: pid + "_" + cat_id + "_" + productType.id + "_" + finish.id + "_" + size.id + "_" + part_no.type, productType: productType.title, finish: finish.title, size: size.title, part: part_no.title};

                        });

                    });

                });
            });
            console.log(result);
            currentObj.data = {filter: result};
            setTemplate(currentObj);

        });
        
        
        $(document).on("click", ".daiva", function () {
            $('#model-close-btn').trigger('click');
            var selectedVal = $("input[name='part']:checked").val();
            if (selectedVal) {
                var ids = selectedVal.split('_');
                var pid = ids[0];
                var cat_id = ids[1];
                var proTypeId = ids[2];
                var finishId = ids[3];
                var sizeId = ids[4];
                var partType = ids[5];
                var product = window.wilsonartFilter.find(function (item) {
                    if (item.product_id == pid && item.cat_id == cat_id)
                        return item;
                });
                $("#product_type_" + pid).val(proTypeId);
                var productType = product.product_type.find(function (item) {
                    if (item.id == proTypeId)
                        return item;
                });
                ItemProcesser.appendFinish(productType, pid, false);
                $("#finish_" + pid).val(finishId);
                var finish = productType.finish.find(function (item) {
                    if (item.id == finishId)
                        return item;
                });
                ItemProcesser.appendSize(finish, pid, false);
                $("#size_"+ pid).val(sizeId);
                var size = finish.sizes.find(function (item) {
                    if (item.id == sizeId)
                        return item;
                });
               
                ItemProcesser.appendPartNumber(size, pid, partType);
            }
        });
        
        
         $(document).on("click", "#reset-model-search", function () {
            setTemplate(currentObj);
        });

        $(document).on("click", ".qty-show", function (e) {
            e.preventDefault();
            console.log(currentObj);

            $.each(currentObj.data.filter, function (index, item) {

                var ids = item.itemId.split('_');
                var pid = ids[0];
                var cat_id = ids[1];


                $("#" + item.itemId).html("Loading...");
                $.ajax({
                    url: ItemProcesser.webServiceUrl,
                    data: {"cutId": ItemProcesser.cutId, "part": encodeURIComponent(item.part), "qty": 1, "wareId": ItemProcesser.wareId, "shipto": ItemProcesser.shipto, "prodid": pid, "category_id": cat_id},
                 
                    success: function (result) {

                        $("#" + item.itemId).html("" + result.net_available);

                    }
                });

                setTimeout(function () { }, 4000);

            });

        });

        $(document).on("keyup", "#pattern_avaliablity_input", function () {
            var str = this.value;
            var result = currentObj.data.filter.filter(function (i) {

                if (i.part.indexOf(str) >= 0)
                    return true;
            });
            //console.log(temp);
            temp.data = {filter: result};
            console.log(temp);
            setTemplate(temp);
        });



    };
    function setTemplate(xx) {
            var progressTmpl = mageTemplate('#filter-template'), tmpl;
            tmpl = progressTmpl(xx);
            $('#table-conent').html(tmpl);
        }

});