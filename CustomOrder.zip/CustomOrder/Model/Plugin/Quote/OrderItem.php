<?php

namespace Bd\CustomOrder\Model\Plugin\Quote;
class OrderItem extends \Magento\Quote\Model\Quote\Item\ToOrderItem
{
    public function aroundConvert(
        \Magento\Quote\Model\Quote\Item\ToOrderItem $subject,
        \Closure $proceed,
        \Magento\Quote\Model\Quote\Item\AbstractItem $item,
        $additional = []
    ) {
        /** @var $orderItem Item */
        $orderItem = $proceed($item, $additional);
        $orderItem->setCustomOption($item->getCustomOption());
        return $orderItem;
    }
}