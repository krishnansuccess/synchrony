function AddProduct(data) {
    var JSONData = {sku: '24-WB03', custom_option: 'daiva'};

    console.log(JSONData);
    var form = document.createElement('form');
    form.setAttribute('action', 'customorder/add/index');
    form.setAttribute('method', 'POST');
    var input1 = document.createElement('input');
    input1.setAttribute('type', 'text');
    input1.setAttribute('name', 'data');
    input1.setAttribute('value', JSON.stringify(JSONData));
    form.appendChild(input1);
    document.body.appendChild(form);
    jQuery(form).submit();
    jQuery(form).css('display', 'none');
}

