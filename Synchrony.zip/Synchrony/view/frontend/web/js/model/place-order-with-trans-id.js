/*jshint browser:true jquery:true*/
/*global alert*/
define([
    'jquery',
    'mage/utils/wrapper'
], function ($, wrapper) {
    'use strict';
    return function (placeOrderAction) {
        /** Override default place order action and add agreement_ids to request */
        return wrapper.wrap(placeOrderAction, function (originalAction, paymentData, redirectOnSuccess, messageContainer) {

            var transId = "121213123123232312312312323dfsd";
            paymentData.extension_attributes={trans_id: transId};
            return originalAction(paymentData, redirectOnSuccess, messageContainer);
        });
    };
});