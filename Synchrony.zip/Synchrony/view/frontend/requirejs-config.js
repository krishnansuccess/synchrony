
var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/place-order': {
                'Daiva_Synchrony/js/model/place-order-with-trans-id': true
            }
        }
    }
};