<?php

namespace Daiva\Synchrony\Plugin;

/**
 * Description of PaymentInformationManagement
 *
 * @author Daiva
 */
class PaymentInformationManagement {

    /** @var \Magento\Sales\Model\OrderFactory $orderFactory */
    protected $orderFactory;
    protected $transactionBuilder;

    public function __construct(
    \Magento\Sales\Model\OrderFactory $orderFactory, \Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface $transactionBuilder
    ) {
        $this->orderFactory = $orderFactory;
        $this->transactionBuilder = $transactionBuilder;
    }

    public function aroundSavePaymentInformationAndPlaceOrder(
    \Magento\Checkout\Model\PaymentInformationManagement $subject, \Closure $proceed, $cartId, \Magento\Quote\Api\Data\PaymentInterface $paymentMethod, \Magento\Quote\Api\Data\AddressInterface $billingAddress = null
    ) {

        $extAttributes = $paymentMethod->getExtensionAttributes();
        $orderId = $proceed($cartId, $paymentMethod, $billingAddress);
        $this->createTransaction($orderId, ['trans_id' => $extAttributes->getTransId()]);
    }

    public function createTransaction($orderId = null, $paymentData = array()) {

        $order = $this->orderFactory->create();
        $order->load($orderId);
        try {
            //get payment object from order object
            $payment = $order->getPayment();
            $payment->setLastTransId("121213123123232312312312323dfsd");
            $payment->setTransactionId("121213123123232312312312323dfsd");
            $payment->setAdditionalInformation(
                    [\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => (array) $paymentData]
            );
            $formatedPrice = $order->getBaseCurrency()->formatTxt(
                    $order->getGrandTotal()
            );

            $message = __('The authorized amount is %1.', $formatedPrice);
            //get the object of builder class
            $trans = $this->transactionBuilder;
            $transaction = $trans->setPayment($payment)
                    ->setOrder($order)
                    ->setTransactionId("121213123123232312312312323dfsd")
                    ->setAdditionalInformation(
                            [\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => (array) $paymentData]
                    )
                    ->setFailSafe(true)
                    //build method creates the transaction and returns the object
                    ->build(\Magento\Sales\Model\Order\Payment\Transaction::TYPE_CAPTURE);

            $payment->addTransactionCommentsToOrder(
                    $transaction, $message
            );
            $payment->setParentTransactionId(null);
            $payment->save();
            $order->save();

            return $transaction->save()->getTransactionId();
        } catch (Exception $e) {
            //log errors here
        }
    }

}
